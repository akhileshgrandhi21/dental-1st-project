# Time slots utility
